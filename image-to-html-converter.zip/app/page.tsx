"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { Upload, Code, Eye } from "lucide-react"

export default function ImageToHtmlConverter() {
  const [imagePreview, setImagePreview] = useState<string | null>(null)
  const [htmlOutput, setHtmlOutput] = useState<string>("")
  const [cssOutput, setCssOutput] = useState<string>("")
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = () => {
        setImagePreview(reader.result as string)
        // In a real application, you would send the image to a backend service
        // that would analyze it and return HTML/CSS
        generatePlaceholderCode()
      }
      reader.readAsDataURL(file)
    }
  }

  const generatePlaceholderCode = () => {
    // This is a placeholder. In a real application, this would be replaced
    // with actual image analysis and HTML generation
    setHtmlOutput(`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Converted Image</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <header>
    <nav class="container">
      <div class="logo">Logo</div>
      <ul class="menu">
        <li><a href="#">Home</a></li>
        <li><a href="#">About</a></li>
        <li><a href="#">Services</a></li>
        <li><a href="#">Contact</a></li>
      </ul>
    </nav>
  </header>
  
  <main class="container">
    <section class="hero">
      <h1>Welcome to our website</h1>
      <p>This is a placeholder for your converted image content</p>
      <button class="cta-button">Learn More</button>
    </section>
  </main>
  
  <footer>
    <div class="container">
      <p>&copy; 2025 Your Company</p>
    </div>
  </footer>
</body>
</html>`)

    setCssOutput(`/* Responsive CSS */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: 'Arial', sans-serif;
  line-height: 1.6;
}

.container {
  width: 100%;
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 20px;
}

header {
  background-color: #f8f9fa;
  padding: 20px 0;
}

nav {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.logo {
  font-size: 1.5rem;
  font-weight: bold;
}

.menu {
  display: flex;
  list-style: none;
}

.menu li {
  margin-left: 20px;
}

.menu a {
  text-decoration: none;
  color: #333;
}

.hero {
  padding: 60px 0;
  text-align: center;
}

h1 {
  font-size: 2.5rem;
  margin-bottom: 20px;
}

.cta-button {
  display: inline-block;
  background-color: #007bff;
  color: white;
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  margin-top: 20px;
  cursor: pointer;
}

footer {
  background-color: #f8f9fa;
  padding: 20px 0;
  text-align: center;
}

/* Responsive styles */
@media (max-width: 768px) {
  .menu {
    flex-direction: column;
    position: absolute;
    top: 60px;
    right: 20px;
    background-color: #f8f9fa;
    padding: 20px;
    display: none;
  }
  
  .menu li {
    margin: 10px 0;
  }
  
  h1 {
    font-size: 2rem;
  }
}`)
  }

  const triggerFileInput = () => {
    fileInputRef.current?.click()
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard
      .writeText(text)
      .then(() => {
        alert("Copied to clipboard!")
      })
      .catch((err) => {
        console.error("Failed to copy: ", err)
      })
  }

  return (
    <div className="container mx-auto p-4 max-w-5xl">
      <h1 className="text-3xl font-bold mb-6 text-center">Image to HTML Converter</h1>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Upload Image</CardTitle>
          <CardDescription>Upload an image to convert it to responsive HTML and CSS</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center gap-4">
            <Input ref={fileInputRef} type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
            <Button onClick={triggerFileInput} className="w-full max-w-xs">
              <Upload className="mr-2 h-4 w-4" /> Select Image
            </Button>

            {imagePreview && (
              <div className="mt-4 border rounded-md p-2 w-full">
                <p className="text-sm text-muted-foreground mb-2">Preview:</p>
                <img
                  src={imagePreview || "/placeholder.svg"}
                  alt="Preview"
                  className="max-w-full h-auto max-h-[300px] mx-auto"
                />
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {imagePreview && (
        <Tabs defaultValue="html" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="html">
              <Code className="mr-2 h-4 w-4" /> HTML
            </TabsTrigger>
            <TabsTrigger value="css">
              <Eye className="mr-2 h-4 w-4" /> CSS
            </TabsTrigger>
          </TabsList>

          <TabsContent value="html">
            <Card>
              <CardHeader>
                <CardTitle>HTML Output</CardTitle>
                <CardDescription>Generated HTML structure based on your image</CardDescription>
              </CardHeader>
              <CardContent>
                <Textarea value={htmlOutput} readOnly className="font-mono text-sm h-[400px]" />
              </CardContent>
              <CardFooter>
                <Button onClick={() => copyToClipboard(htmlOutput)}>Copy HTML</Button>
              </CardFooter>
            </Card>
          </TabsContent>

          <TabsContent value="css">
            <Card>
              <CardHeader>
                <CardTitle>CSS Output</CardTitle>
                <CardDescription>Generated responsive CSS styles</CardDescription>
              </CardHeader>
              <CardContent>
                <Textarea value={cssOutput} readOnly className="font-mono text-sm h-[400px]" />
              </CardContent>
              <CardFooter>
                <Button onClick={() => copyToClipboard(cssOutput)}>Copy CSS</Button>
              </CardFooter>
            </Card>
          </TabsContent>
        </Tabs>
      )}
    </div>
  )
}

